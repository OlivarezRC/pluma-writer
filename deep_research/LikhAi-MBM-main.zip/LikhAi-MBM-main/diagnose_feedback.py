#!/usr/bin/env python3
"""
Diagnostic script to test FeedbackRating custom element.

This script verifies that the FeedbackRating.jsx component exists
and is properly structured for Chainlit.
"""

import os
from pathlib import Path

def check_feedback_component():
    """Check if FeedbackRating component exists and is valid."""
    print("=" * 60)
    print("Feedback Component Diagnostic")
    print("=" * 60)
    print()
    
    # Check file exists
    component_path = Path("public/elements/FeedbackRating.jsx")
    if not component_path.exists():
        print(f"❌ Component file not found: {component_path}")
        return False
    
    print(f"✓ Component file exists: {component_path}")
    print(f"  Size: {component_path.stat().st_size} bytes")
    print()
    
    # Read and check content
    with open(component_path, 'r') as f:
        content = f.read()
    
    # Check for required patterns
    checks = {
        "Import useState": "import { useState } from 'react'",
        "Export default": "export default function FeedbackRating",
        "Props destructuring": "{ messageId, sessionId, userId, model, userMessage, aiResponse }",
        "callAction usage": "await callAction",
        "Return JSX": "return (",
    }
    
    print("Component Structure Checks:")
    all_passed = True
    for check_name, pattern in checks.items():
        if pattern in content:
            print(f"  ✓ {check_name}")
        else:
            print(f"  ❌ {check_name} - Pattern not found: {pattern}")
            all_passed = False
    print()
    
    # Check other custom elements for comparison
    print("Other Custom Elements:")
    elements_dir = Path("public/elements")
    if elements_dir.exists():
        for jsx_file in elements_dir.glob("*.jsx"):
            size = jsx_file.stat().st_size
            print(f"  - {jsx_file.name} ({size} bytes)")
    print()
    
    # Check if component is properly formatted
    lines = content.split('\n')
    print(f"Total lines: {len(lines)}")
    print(f"First 3 lines:")
    for i, line in enumerate(lines[:3], 1):
        print(f"  {i}: {line[:70]}")
    print()
    
    if all_passed:
        print("✓ All checks passed!")
        print()
        print("Next steps:")
        print("1. Restart Chainlit: chainlit run app.py")
        print("2. Clear browser cache (Ctrl+Shift+R or Cmd+Shift+R)")
        print("3. Check browser console for errors")
        print("4. Verify feedback element appears after AI responses")
    else:
        print("❌ Some checks failed. Review component structure.")
    
    print()
    print("=" * 60)
    return all_passed


if __name__ == "__main__":
    check_feedback_component()
