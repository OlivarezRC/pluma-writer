"""
Feedback System Demo

This script demonstrates the feedback storage system functionality.
Run this to test feedback collection without starting the full Chainlit app.
"""

from utils.feedback import get_feedback_storage
from datetime import datetime
import json


def demo_feedback_system():
    """Demonstrate the feedback system with sample data."""
    print("=" * 60)
    print("BSP AI Assistant - Feedback System Demo")
    print("=" * 60)
    print()
    
    # Get feedback storage instance
    storage = get_feedback_storage()
    print(f"✓ Feedback storage initialized")
    print(f"  - CSV:  {storage.csv_file}")
    print(f"  - JSON: {storage.json_file}")
    print(f"  - XLSX: {storage.xlsx_file}")
    print()
    
    # Sample feedback data
    sample_feedbacks = [
        {
            'message_id': 'msg_001',
            'session_id': 'demo_session_001',
            'user_id': 'demo_user@bsp.gov.ph',
            'model_used': 'foundry/gpt-4o',
            'rating': 5,
            'comment': 'Excellent response! Very helpful and accurate.',
            'user_message': 'What is the current monetary policy of BSP?',
            'ai_response': 'The Bangko Sentral ng Pilipinas implements monetary policy...',
            'response_length': 250,
            'rating_category': 'Good'
        },
        {
            'message_id': 'msg_002',
            'session_id': 'demo_session_002',
            'user_id': 'demo_user@bsp.gov.ph',
            'model_used': 'foundry/gpt-4.1-mini',
            'rating': 4,
            'comment': 'Good response, but could be more detailed.',
            'user_message': 'Explain inflation targeting.',
            'ai_response': 'Inflation targeting is a monetary policy framework...',
            'response_length': 180,
            'rating_category': 'Good'
        },
        {
            'message_id': 'msg_003',
            'session_id': 'demo_session_003',
            'user_id': 'demo_user@bsp.gov.ph',
            'model_used': 'foundry/gpt-4o',
            'rating': 3,
            'comment': 'Adequate but missing some context.',
            'user_message': 'What are reserve requirements?',
            'ai_response': 'Reserve requirements refer to the amount of funds...',
            'response_length': 150,
            'rating_category': 'Average'
        },
        {
            'message_id': 'msg_004',
            'session_id': 'demo_session_004',
            'user_id': 'demo_user@bsp.gov.ph',
            'model_used': 'foundry/gpt-4.1-mini',
            'rating': 2,
            'comment': 'Response was too generic and not specific enough.',
            'user_message': 'Latest BSP circular on digital banks?',
            'ai_response': 'BSP has issued various circulars regarding digital banking...',
            'response_length': 120,
            'rating_category': 'Poor'
        },
        {
            'message_id': 'msg_005',
            'session_id': 'demo_session_005',
            'user_id': 'demo_user@bsp.gov.ph',
            'model_used': 'foundry/gpt-4o',
            'rating': 5,
            'comment': '',
            'user_message': 'Summarize the latest financial stability report.',
            'ai_response': 'The latest Financial Stability Report indicates...',
            'response_length': 300,
            'rating_category': 'Good'
        }
    ]
    
    # Save sample feedback
    print("Adding sample feedback entries...")
    for i, feedback in enumerate(sample_feedbacks, 1):
        success = storage.save_feedback(feedback)
        if success:
            print(f"  ✓ Feedback {i}/5 saved - Rating: {feedback['rating']}⭐ - Model: {feedback['model_used']}")
        else:
            print(f"  ✗ Failed to save feedback {i}/5")
    print()
    
    # Get and display statistics
    print("Feedback Statistics:")
    print("-" * 60)
    stats = storage.get_feedback_stats()
    
    print(f"Total Feedback Entries: {stats.get('total_feedback', 0)}")
    print(f"Average Rating: {stats.get('average_rating', 0):.2f} ⭐")
    print()
    
    print("Rating Distribution:")
    for rating, count in sorted(stats.get('rating_distribution', {}).items(), reverse=True):
        stars = '⭐' * int(rating)
        bar = '█' * int(count * 5)
        print(f"  {rating} {stars:5s}: {bar} ({count})")
    print()
    
    print("Category Distribution:")
    for category, count in stats.get('category_distribution', {}).items():
        print(f"  {category:10s}: {count}")
    print()
    
    print("Models Rated:")
    for model in stats.get('models_rated', []):
        print(f"  - {model}")
    print()
    
    print("=" * 60)
    print("Demo completed successfully!")
    print(f"Check the files in: {storage.feedback_dir}")
    print("=" * 60)


if __name__ == "__main__":
    demo_feedback_system()
