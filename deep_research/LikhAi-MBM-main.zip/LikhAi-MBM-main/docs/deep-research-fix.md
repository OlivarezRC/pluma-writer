# Deep Research Mode Routing Fix

## Problem Summary

**Issue**: When using deep_research mode, the system was incorrectly routing through `chat_agent` (Azure AI Foundry) instead of using the dedicated DeepSeek model credentials, causing errors like:

```
Error in on_message: Error generating response in chat_agent: Please refresh this page.
```

## Root Cause

The deep research pipeline (`deep_research/pipeline.py`) requires **separate environment variables** that are different from the standard chat and Azure AI Foundry credentials:

- `AZURE_INFERENCE_ENDPOINT` - Azure AI Inference endpoint (not Azure OpenAI)
- `AZURE_DEEPSEEK_DEPLOYMENT` - DeepSeek R1 model deployment name
- `AZURE_AI_API_KEY` - Azure AI API key (not the same as Foundry)
- `TAVILY_API_KEY` - Tavily web search API key

These were not documented, and the system didn't validate them before execution.

## Changes Made

### 1. Added Environment Variable Validation (`deep_research/pipeline.py`)

```python
# Validate required environment variables
if not _endpoint or not _model_name or not _key:
    missing = []
    if not _endpoint: missing.append("AZURE_INFERENCE_ENDPOINT")
    if not _model_name: missing.append("AZURE_DEEPSEEK_DEPLOYMENT")
    if not _key: missing.append("AZURE_AI_API_KEY")
    raise ValueError(
        f"Missing required environment variables for deep research: {', '.join(missing)}. "
        "Please set these in your .env file to use deep research mode."
    )
```

This ensures that if the environment variables are missing, the error is caught early with a clear message.

### 2. Enhanced Error Handling in `app.py`

Added pre-flight validation before running deep research:

```python
# Verify required environment variables
import os
required_vars = ["AZURE_INFERENCE_ENDPOINT", "AZURE_DEEPSEEK_DEPLOYMENT", "AZURE_AI_API_KEY", "TAVILY_API_KEY"]
missing_vars = [var for var in required_vars if not os.getenv(var)]

if missing_vars:
    error_msg = (
        f"❌ Deep research mode requires the following environment variables to be set: "
        f"{', '.join(missing_vars)}. Please configure these in your .env file."
    )
    logger.error(f"Deep research configuration error: {error_msg}")
    await cl.Message(content=error_msg).send()
    return
```

This provides user-friendly error messages instead of cryptic failures.

### 3. Updated Documentation

#### `sample.env`
Added the required deep research environment variables:

```bash
# Deep Research Mode Configuration (Azure AI Inference with DeepSeek)
AZURE_INFERENCE_ENDPOINT=https://your-inference-endpoint.inference.ai.azure.com
AZURE_DEEPSEEK_DEPLOYMENT=deepseek-r1
AZURE_AI_API_KEY=your_azure_ai_api_key

# Tavily API for Web Research (required for deep_research mode)
TAVILY_API_KEY=your_tavily_api_key
```

#### `deep_research/README.md`
Created comprehensive documentation covering:
- Architecture and components
- Configuration requirements
- Usage flow
- Error handling
- Troubleshooting guide
- Extension examples

#### Main `README.md`
- Updated architecture from "dual-route" to "triple-route"
- Added Deep Research Mode section with configuration and usage
- Updated provider routing documentation

#### `.github/copilot-instructions.md`
- Updated architecture overview
- Added Deep Research Mode routing logic
- Documented environment variables
- Added to component list

## Verification Steps

### 1. Check Environment Variables

Ensure your `.env` file has all required variables:

```bash
# Check if variables are set
echo $AZURE_INFERENCE_ENDPOINT
echo $AZURE_DEEPSEEK_DEPLOYMENT
echo $AZURE_AI_API_KEY
echo $TAVILY_API_KEY
```

### 2. Test Deep Research Mode

1. Start the application:
   ```bash
   chainlit run app.py --watch
   ```

2. In the UI, switch to "Deep Research" mode (3-mode toggle)

3. Enter a test query: "Explain BSP monetary policy"

4. Expected behavior:
   - ✅ If variables are set: Research pipeline executes
   - ❌ If variables are missing: Clear error message with list of missing variables

### 3. Monitor Logs

Check logs for proper routing:

```bash
tail -f logs/app.log | grep "Deep Research"
```

Expected log entries:
```
🔬 Deep Research mode activated for query: ...
✅ Deep research environment validated
✅ Deep research completed for: ...
```

If errors occur:
```
❌ Deep research configuration error: Missing required environment variables...
```

## Architecture Flow

### Before Fix
```
User Query (deep_research mode)
    ↓
app.py checks mode
    ↓
Missing validation
    ↓
pipeline.py tries to initialize model
    ↓
Environment variables are None
    ↓
Model initialization fails silently
    ↓
Falls through to standard chat logic
    ↓
Routes to chat_agent (wrong provider)
    ↓
Error: "Error generating response in chat_agent"
```

### After Fix
```
User Query (deep_research mode)
    ↓
app.py checks mode
    ↓
✅ Validates environment variables FIRST
    ↓
If missing: Show clear error and exit
    ↓
If present: pipeline.py initializes model
    ↓
✅ Model initialization with validation
    ↓
If fails: Raise ValueError with clear message
    ↓
If succeeds: Run deep research pipeline
    ↓
Return research report
```

## Key Takeaways

1. **Separate Credentials**: Deep research uses completely different Azure services:
   - Azure AI Inference (not Azure OpenAI)
   - DeepSeek R1 model (not GPT-4)
   - Tavily API (not Foundry search)

2. **Early Validation**: Check environment variables BEFORE attempting to use them

3. **Clear Error Messages**: Help users understand what's missing and how to fix it

4. **Proper Routing**: Deep research check happens FIRST in `on_message`, before any other chat logic

5. **Documentation**: All required variables are now documented in sample.env and READMEs

## Next Steps

1. **Set Environment Variables**: Add the 4 required variables to your `.env` file
2. **Test the Fix**: Follow verification steps above
3. **Monitor**: Check logs to ensure proper routing
4. **Update Azure Resources**: If you don't have Azure AI Inference endpoint, create one in Azure Portal

## Troubleshooting

### Still Getting chat_agent Errors?

1. Verify `.env` file is loaded:
   ```python
   import os
   print(os.getenv("AZURE_INFERENCE_ENDPOINT"))
   ```

2. Restart the application after setting environment variables

3. Check if mode is actually set to "deep_research":
   ```python
   # In logs, look for:
   "Mode set to: deep_research"
   ```

### Environment Variables Not Loading?

1. Check `.env` file location (should be in project root)
2. Verify no typos in variable names
3. Ensure no quotes around values (unless value contains spaces)
4. Restart terminal/IDE after modifying `.env`

### Model Initialization Fails?

1. Verify Azure AI Inference endpoint is correct
2. Check API key has proper permissions
3. Ensure deployment name matches Azure resource
4. Test endpoint connectivity with curl:
   ```bash
   curl -H "Authorization: Bearer $AZURE_AI_API_KEY" $AZURE_INFERENCE_ENDPOINT
   ```
