# Feedback System Implementation Guide

## Overview
The BSP AI Assistant now includes a comprehensive 5-star rating feedback system that captures user satisfaction for every AI response.

## Architecture

```
User Interaction Flow:
┌─────────────────────────────────────────────────────────────────┐
│ 1. User sends message                                           │
│ 2. AI generates response                                        │
│ 3. Response displayed with 5-star rating component              │
│ 4. User clicks star rating → Modal opens                        │
│ 5. User optionally adds comment → Submits feedback             │
│ 6. Feedback saved to local files (CSV, JSON, XLSX)             │
│ 7. Feedback automatically synced to Azure Blob Storage          │
└─────────────────────────────────────────────────────────────────┘
```

## Components

### 1. Frontend Component
**File**: `public/elements/FeedbackRating.jsx`

```jsx
<FeedbackRating 
  messageId="msg_123"
  sessionId="session_456"
  userId="user@bsp.gov.ph"
  model="foundry/gpt-4o"
  userMessage="What is BSP's policy?"
  aiResponse="BSP implements..."
/>
```

**Features**:
- Interactive 5-star rating UI
- Modal dialog for comments
- Character counter (500 max)
- Skip option for quick dismissal
- Success feedback confirmation

### 2. Backend Storage
**File**: `utils/feedback.py`

**Key Classes**:
- `FeedbackStorage`: Main storage handler
- `get_feedback_storage()`: Singleton accessor

**Storage Formats**:
1. **CSV**: `data/feedback/feedback.csv` - For spreadsheet analysis
2. **JSON**: `data/feedback/feedback.json` - For programmatic access
3. **XLSX**: `data/feedback/feedback.xlsx` - For Excel viewing

**Azure Integration**:
- Automatic upload to blob container `feedback`
- Maintains sync across all file formats
- Connection via `APP_AZURE_STORAGE_CONNECTION_STRING`

### 3. Integration Point
**File**: `app.py`

**Action Callback**:
```python
@cl.action_callback("save_feedback")
async def save_feedback(action: cl.Action):
    feedback_data = action.payload
    feedback_storage = get_feedback_storage()
    success = feedback_storage.save_feedback(feedback_data)
    return {"success": success}
```

**Message Handler**:
```python
# In on_message handler
feedback_element = cl.CustomElement(
    name="FeedbackRating",
    props={...},
    display="inline"
)
await cl.Message(content=response, elements=[feedback_element]).send()
```

## Data Schema

Every feedback entry includes:

| Field | Type | Description | Max Length |
|-------|------|-------------|------------|
| `timestamp` | ISO 8601 | Submission timestamp | - |
| `session_id` | String | Chat session ID | - |
| `user_id` | String | User identifier | - |
| `model_used` | String | LLM model name | - |
| `rating` | Integer | Star rating (1-5) | - |
| `comment` | String | User comment | 500 chars |
| `user_message` | String | Original query | 5000 chars |
| `ai_response` | String | AI response | 10000 chars |
| `response_length` | Integer | Response char count | - |
| `rating_category` | String | Poor/Average/Good | - |
| `message_id` | String | Unique message ID | - |

## Rating Categories

Automatically assigned based on star rating:
- **Poor**: 1-2 stars
- **Average**: 3 stars  
- **Good**: 4-5 stars

## Configuration

### Environment Variables
```bash
# Required for Azure Blob sync
APP_AZURE_STORAGE_ACCOUNT=your-storage-account-name
APP_AZURE_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=https;...
```

### Directory Structure
```
data/
└── feedback/
    ├── README.md           # Documentation
    ├── feedback.csv        # CSV format (gitignored)
    ├── feedback.json       # JSON format (gitignored)
    └── feedback.xlsx       # Excel format (gitignored)
```

## Usage Examples

### Basic Feedback Collection
Automatically happens when user rates a response. No manual intervention needed.

### Accessing Feedback Statistics
```python
from utils.feedback import get_feedback_storage

storage = get_feedback_storage()
stats = storage.get_feedback_stats()

print(f"Total feedback: {stats['total_feedback']}")
print(f"Average rating: {stats['average_rating']:.2f}")
print(f"Rating distribution: {stats['rating_distribution']}")
```

### Manual Feedback Save
```python
feedback_data = {
    'message_id': 'msg_123',
    'session_id': 'sess_456',
    'user_id': 'user@bsp.gov.ph',
    'model_used': 'foundry/gpt-4o',
    'rating': 5,
    'comment': 'Excellent!',
    'user_message': 'Query text',
    'ai_response': 'Response text',
    'response_length': 100,
    'rating_category': 'Good'
}

storage = get_feedback_storage()
success = storage.save_feedback(feedback_data)
```

## Testing

### Run Feedback Tests
```bash
# Run all feedback tests
python -m pytest tests/test_feedback.py -v

# Run specific test
python -m pytest tests/test_feedback.py::test_save_feedback_success -v
```

### Demo Script
```bash
# Run demo to see feedback system in action
python demo_feedback.py
```

## Azure Blob Storage Access

### Via Azure Portal
1. Navigate to Azure Portal
2. Go to Storage Account: `mbmchat`
3. Select Containers → `feedback`
4. Download files: `feedback.csv`, `feedback.json`, `feedback.xlsx`

### Via Azure Storage Explorer
1. Connect using connection string
2. Browse to `feedback` container
3. View/download feedback files

### Via Azure CLI
```bash
# List feedback files
az storage blob list --account-name mbmchat --container-name feedback

# Download feedback.csv
az storage blob download \
  --account-name mbmchat \
  --container-name feedback \
  --name feedback.csv \
  --file ./feedback.csv
```

## Troubleshooting

### Feedback Not Saving
1. Check logs in `logs/app.log` for errors
2. Verify `data/feedback/` directory exists
3. Check file permissions
4. Verify Azure connection string is valid

### Azure Upload Failing
1. Check `APP_AZURE_STORAGE_CONNECTION_STRING` is set
2. Verify network connectivity to Azure
3. Check container `feedback` exists
4. Review Azure storage account permissions

### UI Component Not Appearing
1. Verify `public/elements/FeedbackRating.jsx` exists
2. Check browser console for React errors
3. Verify Chainlit custom elements are enabled
4. Clear browser cache

## Future Enhancements

Potential improvements to consider:
- [ ] Add feedback analytics dashboard
- [ ] Email notifications for low ratings
- [ ] Feedback export API endpoint
- [ ] Real-time feedback alerts
- [ ] Sentiment analysis on comments
- [ ] Feedback trends visualization
- [ ] Model performance comparison reports
- [ ] User satisfaction metrics dashboard

## Security Considerations

- Feedback files excluded from Git (`.gitignore`)
- Text fields truncated to prevent excessive storage
- Azure Blob access via connection string (secure)
- User IDs logged for accountability
- No PII exposed in frontend components

## Maintenance

### Regular Tasks
- Monitor feedback files size (implement rotation if needed)
- Review Azure Blob storage costs
- Analyze feedback trends monthly
- Archive old feedback data annually

### Cleanup Script
Create a cleanup script if feedback files grow too large:
```python
# Archive old feedback
import shutil
from datetime import datetime

archive_dir = f"data/feedback/archive_{datetime.now().strftime('%Y%m%d')}"
# Move files to archive...
```
