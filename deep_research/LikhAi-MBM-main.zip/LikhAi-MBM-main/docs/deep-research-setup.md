# Deep Research Mode - Quick Setup Guide

## Required Environment Variables

Add these to your `.env` file:

```bash
# Deep Research Mode Configuration
AZURE_INFERENCE_ENDPOINT=https://your-inference-endpoint.inference.ai.azure.com
AZURE_DEEPSEEK_DEPLOYMENT=deepseek-r1
AZURE_AI_API_KEY=your_azure_ai_api_key
TAVILY_API_KEY=your_tavily_api_key
```

## Where to Get These Values

### 1. AZURE_INFERENCE_ENDPOINT

**Azure Portal Steps:**
1. Navigate to Azure AI Studio → Your Project
2. Go to "Deployments" section
3. Select your DeepSeek deployment
4. Copy the "Endpoint" URL (should end with `.inference.ai.azure.com`)

### 2. AZURE_DEEPSEEK_DEPLOYMENT

**Azure Portal Steps:**
1. Same location as above (Deployments section)
2. Copy the "Deployment Name" (e.g., `deepseek-r1`, `deepseek-r1-preview`)

### 3. AZURE_AI_API_KEY

**Azure Portal Steps:**
1. In your Azure AI Studio project
2. Go to "Settings" → "Keys and Endpoint"
3. Copy either "Key 1" or "Key 2"

**Alternative (Azure CLI):**
```bash
az cognitiveservices account keys list \
  --name <your-service-name> \
  --resource-group <your-resource-group>
```

### 4. TAVILY_API_KEY

**Tavily Website:**
1. Go to https://tavily.com
2. Sign up or log in
3. Navigate to "API Keys" in dashboard
4. Copy your API key

**Note:** Tavily offers a free tier with limited searches per month.

## Verification

After setting the variables, verify they're loaded:

```bash
# In terminal
echo $AZURE_INFERENCE_ENDPOINT
echo $AZURE_DEEPSEEK_DEPLOYMENT
echo $AZURE_AI_API_KEY
echo $TAVILY_API_KEY
```

Or in Python:

```python
import os
from dotenv import load_dotenv

load_dotenv()

vars_to_check = [
    "AZURE_INFERENCE_ENDPOINT",
    "AZURE_DEEPSEEK_DEPLOYMENT", 
    "AZURE_AI_API_KEY",
    "TAVILY_API_KEY"
]

for var in vars_to_check:
    value = os.getenv(var)
    status = "✅" if value else "❌"
    print(f"{status} {var}: {'Set' if value else 'Missing'}")
```

## Testing Deep Research Mode

1. Start the app:
   ```bash
   chainlit run app.py --watch
   ```

2. Switch to "Deep Research" mode in the UI

3. Try a test query:
   ```
   Explain the concept of monetary policy
   ```

4. Expected result:
   - Progress updates as research iterates
   - Final comprehensive report with sources and images

## Common Issues

### "Missing required environment variables"

**Solution:** Double-check spelling and ensure variables are in `.env` file at project root.

### "Model initialization failed"

**Solutions:**
- Verify endpoint URL is correct (should be full URL with `https://`)
- Check API key is valid and not expired
- Ensure deployment name matches exactly what's in Azure

### "Tavily API error"

**Solutions:**
- Verify API key is correct
- Check Tavily account has sufficient credits
- Ensure rate limits haven't been exceeded

## Alternative: Using Environment Variables Directly

Instead of `.env` file, you can set variables directly:

**Linux/Mac:**
```bash
export AZURE_INFERENCE_ENDPOINT="https://your-endpoint.inference.ai.azure.com"
export AZURE_DEEPSEEK_DEPLOYMENT="deepseek-r1"
export AZURE_AI_API_KEY="your-key"
export TAVILY_API_KEY="your-tavily-key"
```

**Windows PowerShell:**
```powershell
$env:AZURE_INFERENCE_ENDPOINT="https://your-endpoint.inference.ai.azure.com"
$env:AZURE_DEEPSEEK_DEPLOYMENT="deepseek-r1"
$env:AZURE_AI_API_KEY="your-key"
$env:TAVILY_API_KEY="your-tavily-key"
```

**Windows CMD:**
```cmd
set AZURE_INFERENCE_ENDPOINT=https://your-endpoint.inference.ai.azure.com
set AZURE_DEEPSEEK_DEPLOYMENT=deepseek-r1
set AZURE_AI_API_KEY=your-key
set TAVILY_API_KEY=your-tavily-key
```

## For Production (Azure App Service)

Configure in Azure Portal:

1. Go to your App Service
2. Navigate to "Configuration" → "Application settings"
3. Click "New application setting" for each variable:
   - Name: `AZURE_INFERENCE_ENDPOINT`
   - Value: `https://your-endpoint.inference.ai.azure.com`
4. Save changes and restart the app

## Security Best Practices

1. **Never commit `.env` to version control**
   - Already in `.gitignore`
   - Double-check before committing

2. **Rotate keys regularly**
   - Update in Azure Portal
   - Update in `.env` or App Service config

3. **Use Azure Key Vault for production**
   - Store sensitive keys in Key Vault
   - Reference in App Service configuration

4. **Limit API key permissions**
   - Use principle of least privilege
   - Only grant necessary access

## Getting Help

- **Documentation**: See `deep_research/README.md` for detailed guide
- **Troubleshooting**: Check `docs/deep-research-fix.md` for common issues
- **Logs**: Monitor `logs/app.log` for detailed error messages
