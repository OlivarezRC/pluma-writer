# LiteLLM-based chat completion functionality for BSP AI Assistant
# This file handles standard LLM provider interactions using LiteLLM
# Supporting multiple providers like Azure OpenAI, Gemini, and Perplexity

import time
import re
import chainlit as cl
from loguru import logger
from litellm import completion
from utils.utils import get_llm_models


def format_citation_item(citation):
    """
    Normalize a citation item to (label, url).

    Handles:
    - string: "https://..." or "Bangko Sentral ...pdf"
    - dict: {"url": "...", "title": "..."} or {"file_name": "..."}
    """
    # Just a string
    if isinstance(citation, str):
        if citation.startswith("http://") or citation.startswith("https://"):
            # Treat as URL string
            return citation, citation  # label, url
        else:
            # Probably internal filename / identifier
            return citation, None

    # Dict-like citation (from Foundry / tools)
    if isinstance(citation, dict):
        title = (
            citation.get("title")
            or citation.get("file_name")
            or citation.get("filename")
            or citation.get("name")
            or citation.get("id")
            or "Source"
        )
        url = citation.get("url") or citation.get("link")
        return title, url

    # Fallback
    return str(citation), None


# Get LLM parameters
def get_llm_params(messages: list, use_tools: bool = False) -> dict:
    """
    Build parameters for LLM API calls based on current session configuration.
    
    Constructs the parameter dictionary needed for LiteLLM completion calls,
    including model-specific settings, API keys, and optional tools.
    
    Args:
        messages: List of message objects to send to the LLM
        use_tools: Whether to include function calling tools (default: False)
        
    Returns:
        dict: Complete parameter dictionary for LiteLLM completion
    """
    # Get chat settings
    chat_settings = cl.user_session.get("chat_settings")
    chat_profile = cl.user_session.get("chat_profile")
    temperature = chat_settings.get("temperature")
    provider = chat_settings.get("model_provider")
    model_name = chat_settings.get("model_name")

    # Get the model details from the selected model
    llm_details = next(
        (item for item in get_llm_models() if item["model_deployment"] == chat_profile),
        {}
    )
    logger.debug(f"messages: {messages}")

    chat_parameters = {
        "model": chat_profile,
        "messages": messages,
        "stream": True,
    }
    
    # Only add api_key if it exists in llm_details
    if "api_key" in llm_details:
        chat_parameters["api_key"] = llm_details["api_key"]

    tools = [
        {
            "type": "function",
            "function": {
                "name": "search_web",
                "description": "Search the web using SERP API",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The search query"
                        }
                    },
                    "required": ["query"]
                }
            }
        }
    ]

    if provider == "azure":
        if llm_details.get("api_version"):
            chat_parameters["api_version"] = llm_details["api_version"]

        if llm_details.get("api_endpoint"):
            chat_parameters["api_base"] = llm_details["api_endpoint"]

        # Models that accept temperature
        if model_name not in ["o3-mini"]:
            chat_parameters["temperature"] = temperature
    else:
        chat_parameters["temperature"] = float(temperature)

    # Append search_web tool if requested
    if use_tools:
        chat_parameters["tools"] = tools

    return chat_parameters


# Chat completion function
async def chat_completion(messages: list, use_tools: bool = False) -> str:
    """
    Generate a response from the configured LLM provider using LiteLLM.
    
    Streams the response from the LLM and handles citations, thinking indicators,
    and error recovery. Works with multiple providers through LiteLLM.
    
    Args:
        messages: List of messages to send to the model
        use_tools: Whether to enable function calling tools (default: False)
    
    Returns:
        str: The generated response from the model
        
    Raises:
        RuntimeError: If response generation fails
    """
    try:
        # Get chat settings
        chat_settings = cl.user_session.get("chat_settings")
        model_name = chat_settings.get("model_name")

        # Show thinking message to user
        msg = await cl.Message(f"[{model_name}] thinking...", author="agent").send()
        chat_parameters = get_llm_params(messages, use_tools=use_tools)
        logger.info(f"Chat parameters: {chat_parameters}")

        # Create chat completion (streaming)
        response = completion(**chat_parameters)
        is_thinking = True

        # We'll collect the last set of citations (if any)
        last_citations = None

        for chunk in response:
            # Clear the "thinking" placeholder on first actual content
            if is_thinking:
                msg.content = ""
                is_thinking = False
                logger.info(
                    f"Elapsed time: {(time.time() - cl.user_session.get('start_time')):.2f} seconds"
                )

            # Stream content tokens into the message
            if getattr(chunk, "choices", None) and chunk.choices[0].delta.content:
                msg.content += chunk.choices[0].delta.content
                await msg.update()

            # --- Robust citation extraction from chunk ---
            citations = None

            # Case 1: chunk has a 'citations' attribute
            if hasattr(chunk, "citations"):
                citations = getattr(chunk, "citations", None)

            # Case 2: chunk behaves like a dict
            elif isinstance(chunk, dict) and "citations" in chunk:
                citations = chunk.get("citations")

            # Case 3: some providers attach citations to the message object
            elif getattr(chunk, "choices", None):
                msg_obj = getattr(chunk.choices[0], "message", None)
                if msg_obj is not None and hasattr(msg_obj, "citations"):
                    citations = getattr(msg_obj, "citations", None)

            if citations:
                last_citations = citations

        logger.info("Checking for citations and cleaning content inside chat_completion.")

        # --- 1) Extract and remove inline content reference markers ---
        # Pattern for Foundry-style refs: 
        inline_source_labels = []
        pattern = r"【\d+:\d+†([^】]+)】"

        inline_source_labels = re.findall(pattern, msg.content)
        # Remove the inline markers from the visible answer
        msg.content = re.sub(pattern, "", msg.content).strip()

        # --- 2) Remove any Sources block produced by the model itself ---
        # e.g., "**Sources:**\nNo URL Citation" or any tailing Sources section
        msg.content = re.sub(
            r"\*\*Sources:\*\*[\s\S]*$",
            "",
            msg.content
        ).strip()

        # --- 3) Build a clean, deduplicated Sources section ---
        # We'll merge references from:
        # - inline_source_labels
        # - last_citations (from chunk metadata)
        sources_map = {}  # label -> url (or None)

        # From inline content refs (internal BSP knowledge files)
        for label in inline_source_labels:
            label = label.strip()
            if label:
                # Only set if not present; last_citations may later override with a URL
                sources_map.setdefault(label, None)

        # From metadata citations
        if last_citations:
            for c in last_citations:
                label, url = format_citation_item(c)
                if not label:
                    continue

                # Skip "No URL Citation" junk
                if label.strip().lower() == "no url citation":
                    continue

                label = label.strip()
                # If label already exists with no URL and we now have a URL, update
                if label in sources_map:
                    if sources_map[label] is None and url:
                        sources_map[label] = url
                else:
                    sources_map[label] = url

        # Append Sources block only if we have at least one valid source
        if sources_map:
            msg.content += "\n\n**Sources:**"
            # Sort by label for consistency
            for label in sorted(sources_map.keys(), key=lambda x: x.lower()):
                url = sources_map[label]
                if url:
                    # External or internal with URL → clickable link
                    msg.content += f"\n- [{label}]({url})"
                else:
                    # Internal knowledge file (vector store) → just show filename
                    # If you want BSP style, use: f"\n- (BSP ► {label})"
                    msg.content += f"\n- {label}"

        logger.info(f"Final message content (after citation handling): {msg.content}")

        # Remove the thinking message wrapper if model used <think> tags
        if msg and msg.content.startswith("<think>"):
            msg.content = msg.content.split("</think>")[-1].strip()

        await msg.update()
        return msg.content

    except Exception as e:
        raise RuntimeError(f"Error generating response in chat_completion: {str(e)}")
