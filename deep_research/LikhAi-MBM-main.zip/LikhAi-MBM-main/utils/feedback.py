"""
Feedback storage utility for BSP AI Assistant.

This module handles storage of user feedback ratings in multiple formats:
- Local storage: CSV, JSON, and XLSX files
- Cloud storage: Azure Blob Storage

All feedback includes timestamp, session info, model details, rating, and comments.
"""

import os
import json
import csv
import pandas as pd
from datetime import datetime
from typing import Dict, Any
from pathlib import Path
from azure.storage.blob import BlobServiceClient, ContentSettings
from azure.identity import DefaultAzureCredential
from loguru import logger
from dotenv import load_dotenv

load_dotenv()


class FeedbackStorage:
    """
    Handles storage of user feedback to local files and Azure Blob Storage.
    
    Supports multiple storage formats (CSV, JSON, XLSX) with automatic
    Azure Blob sync for backup and centralized access.
    """
    
    def __init__(self):
        """Initialize feedback storage with Azure Blob Storage connection."""
        self.feedback_dir = Path("data/feedback")
        self.feedback_dir.mkdir(parents=True, exist_ok=True)
        
        # File paths
        self.csv_file = self.feedback_dir / "feedback.csv"
        self.json_file = self.feedback_dir / "feedback.json"
        self.xlsx_file = self.feedback_dir / "feedback.xlsx"
        
        # Azure Blob Storage configuration
        self.storage_account = os.getenv("APP_AZURE_STORAGE_ACCOUNT")
        self.connection_string = os.getenv("APP_AZURE_STORAGE_CONNECTION_STRING")
        self.container_name = "feedback"
        
        # Initialize blob service client
        self.blob_service_client = None
        if self.connection_string:
            try:
                self.blob_service_client = BlobServiceClient.from_connection_string(
                    self.connection_string
                )
                # Ensure container exists
                self._ensure_container_exists()
                logger.info("Azure Blob Storage initialized for feedback")
            except Exception as e:
                logger.error(f"Failed to initialize Azure Blob Storage: {str(e)}")
        else:
            logger.warning("Azure Blob Storage connection string not found. Feedback will only be stored locally.")
        
        # Initialize files if they don't exist
        self._initialize_files()
    
    def _ensure_container_exists(self) -> None:
        """Create the feedback container if it doesn't exist."""
        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            if not container_client.exists():
                container_client.create_container()
                logger.info(f"Created Azure Blob container: {self.container_name}")
        except Exception as e:
            logger.error(f"Error ensuring container exists: {str(e)}")
    
    def _initialize_files(self) -> None:
        """Initialize empty feedback files if they don't exist."""
        # CSV
        if not self.csv_file.exists():
            with open(self.csv_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=[
                    'timestamp', 'session_id', 'user_id', 'model_used', 'rating',
                    'comment', 'user_message', 'ai_response', 'response_length',
                    'rating_category', 'message_id'
                ])
                writer.writeheader()
            logger.info(f"Initialized CSV feedback file: {self.csv_file}")
        
        # JSON
        if not self.json_file.exists():
            with open(self.json_file, 'w', encoding='utf-8') as f:
                json.dump([], f)
            logger.info(f"Initialized JSON feedback file: {self.json_file}")
        
        # XLSX
        if not self.xlsx_file.exists():
            df = pd.DataFrame(columns=[
                'timestamp', 'session_id', 'user_id', 'model_used', 'rating',
                'comment', 'user_message', 'ai_response', 'response_length',
                'rating_category', 'message_id'
            ])
            df.to_excel(self.xlsx_file, index=False, engine='openpyxl')
            logger.info(f"Initialized XLSX feedback file: {self.xlsx_file}")
    
    def save_feedback(self, feedback_data: Dict[str, Any]) -> bool:
        """
        Save feedback to all storage formats (CSV, JSON, XLSX, Azure Blob).
        
        Args:
            feedback_data: Dictionary containing feedback fields:
                - message_id: Unique message identifier
                - session_id: Chat session ID
                - user_id: User identifier
                - model_used: LLM model name
                - rating: Rating value (1-5)
                - comment: User comment (optional)
                - user_message: Original user message
                - ai_response: AI response text
                - response_length: Length of AI response
                - rating_category: Category (Poor/Average/Good)
        
        Returns:
            bool: True if save successful, False otherwise
        """
        try:
            # Add timestamp
            feedback_data['timestamp'] = datetime.now().isoformat()
            
            # Set defaults for optional fields
            feedback_data.setdefault('session_id', 'unknown-session')
            feedback_data.setdefault('user_id', 'anonymous')
            feedback_data.setdefault('message_id', 'unknown-message')
            feedback_data.setdefault('model_used', 'unknown-model')
            
            # Validate required fields (only rating and category are truly required)
            required_fields = ['rating', 'rating_category']
            for field in required_fields:
                if field not in feedback_data or feedback_data[field] is None:
                    logger.error(f"Missing required field: {field}")
                    return False
            
            # Truncate long text fields for storage
            if 'user_message' in feedback_data and feedback_data['user_message']:
                feedback_data['user_message'] = str(feedback_data['user_message'])[:5000]
            if 'ai_response' in feedback_data and feedback_data['ai_response']:
                feedback_data['ai_response'] = str(feedback_data['ai_response'])[:10000]
            if 'comment' in feedback_data and feedback_data['comment']:
                feedback_data['comment'] = str(feedback_data['comment'])[:500]
            
            # Save to CSV
            self._save_to_csv(feedback_data)
            
            # Save to JSON
            self._save_to_json(feedback_data)
            
            # Save to XLSX
            self._save_to_xlsx(feedback_data)
            
            # Upload to Azure Blob Storage
            if self.blob_service_client:
                self._upload_to_blob()
            
            logger.info(f"Feedback saved successfully for session {feedback_data['session_id']}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving feedback: {str(e)}")
            return False
    
    def _save_to_csv(self, feedback_data: Dict[str, Any]) -> None:
        """Append feedback to CSV file."""
        with open(self.csv_file, 'a', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'timestamp', 'session_id', 'user_id', 'model_used', 'rating',
                'comment', 'user_message', 'ai_response', 'response_length',
                'rating_category', 'message_id'
            ])
            writer.writerow(feedback_data)
        logger.debug("Feedback appended to CSV")
    
    def _save_to_json(self, feedback_data: Dict[str, Any]) -> None:
        """Append feedback to JSON file."""
        # Read existing data
        with open(self.json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Append new feedback
        data.append(feedback_data)
        
        # Write back
        with open(self.json_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.debug("Feedback appended to JSON")
    
    def _save_to_xlsx(self, feedback_data: Dict[str, Any]) -> None:
        """Append feedback to XLSX file."""
        # Read existing data
        df_existing = pd.read_excel(self.xlsx_file, engine='openpyxl')
        
        # Create new row
        df_new = pd.DataFrame([feedback_data])
        
        # Concatenate and save
        df_combined = pd.concat([df_existing, df_new], ignore_index=True)
        df_combined.to_excel(self.xlsx_file, index=False, engine='openpyxl')
        logger.debug("Feedback appended to XLSX")
    
    def _upload_to_blob(self) -> None:
        """Upload all feedback files to Azure Blob Storage."""
        try:
            container_client = self.blob_service_client.get_container_client(
                self.container_name
            )
            
            # Upload each file
            for file_path in [self.csv_file, self.json_file, self.xlsx_file]:
                blob_name = f"{file_path.name}"
                blob_client = container_client.get_blob_client(blob_name)
                
                # Determine content type
                content_type = {
                    '.csv': 'text/csv',
                    '.json': 'application/json',
                    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                }.get(file_path.suffix, 'application/octet-stream')
                
                with open(file_path, 'rb') as data:
                    blob_client.upload_blob(
                        data,
                        overwrite=True,
                        content_settings=ContentSettings(content_type=content_type)
                    )
                
                logger.debug(f"Uploaded {file_path.name} to Azure Blob Storage")
            
        except Exception as e:
            logger.error(f"Error uploading to Azure Blob Storage: {str(e)}")
    
    def get_feedback_stats(self) -> Dict[str, Any]:
        """
        Get statistics about stored feedback.
        
        Returns:
            Dictionary containing feedback statistics
        """
        try:
            df = pd.read_excel(self.xlsx_file, engine='openpyxl')
            
            stats = {
                'total_feedback': len(df),
                'average_rating': df['rating'].mean() if len(df) > 0 else 0,
                'rating_distribution': df['rating'].value_counts().to_dict() if len(df) > 0 else {},
                'category_distribution': df['rating_category'].value_counts().to_dict() if len(df) > 0 else {},
                'models_rated': df['model_used'].unique().tolist() if len(df) > 0 else []
            }
            
            return stats
        except Exception as e:
            logger.error(f"Error getting feedback stats: {str(e)}")
            return {}


# Global instance
_feedback_storage = None


def get_feedback_storage() -> FeedbackStorage:
    """
    Get or create the global FeedbackStorage instance.
    
    Returns:
        FeedbackStorage: Global feedback storage instance
    """
    global _feedback_storage
    if _feedback_storage is None:
        _feedback_storage = FeedbackStorage()
    return _feedback_storage
