# Deep Research Mode - Quick Reference

## ✅ What Was Fixed

Deep Research mode now correctly routes to DeepSeek R1 model instead of chat_agent.

## 🔧 Required Environment Variables

```bash
AZURE_INFERENCE_ENDPOINT=https://your-endpoint.inference.ai.azure.com
AZURE_DEEPSEEK_DEPLOYMENT=deepseek-r1
AZURE_AI_API_KEY=your-azure-ai-key
TAVILY_API_KEY=your-tavily-key
```

## 🚀 Quick Setup

1. **Copy variables to `.env`**:
   ```bash
   cp sample.env .env
   # Edit .env with your credentials
   ```

2. **Verify setup**:
   ```bash
   python -c "import os; from dotenv import load_dotenv; load_dotenv(); print('✅' if all([os.getenv(v) for v in ['AZURE_INFERENCE_ENDPOINT','AZURE_DEEPSEEK_DEPLOYMENT','AZURE_AI_API_KEY','TAVILY_API_KEY']]) else '❌')"
   ```

3. **Start app**:
   ```bash
   chainlit run app.py --watch
   ```

4. **Test**:
   - Switch to "Deep Research" mode
   - Enter: "Explain monetary policy"
   - Wait for research report

## 📊 Error Messages

| Message | Fix |
|---------|-----|
| Missing required environment variables | Add variables to `.env` |
| Model initialization failed | Check Azure endpoint and key |
| Tavily API error | Verify Tavily API key |
| Error generating response in chat_agent | ✅ FIXED - Now routes correctly |

## 📚 Documentation

- **Setup**: `docs/deep-research-setup.md`
- **Details**: `deep_research/README.md`
- **Troubleshooting**: `docs/deep-research-fix.md`

## 🔍 Verification

```bash
# Check variables loaded
echo $AZURE_INFERENCE_ENDPOINT

# Check module imports
python -c "from deep_research import pipeline; print('✅ OK')"

# Check app imports
python -c "import app; print('✅ OK')"
```

## 💡 Key Changes

1. ✅ Lazy model initialization (no import-time errors)
2. ✅ Environment variable validation
3. ✅ Clear error messages
4. ✅ Complete documentation

## 🎯 Files Changed

- `deep_research/pipeline.py` - Lazy init + validation
- `app.py` - Pre-flight validation
- `sample.env` - Added 4 new variables
- `README.md` - Added Deep Research section
- `.github/copilot-instructions.md` - Updated architecture

## 📝 New Documentation

- `deep_research/README.md` - Full guide
- `docs/deep-research-setup.md` - Setup instructions
- `docs/deep-research-fix.md` - Fix details
- `docs/CHANGELOG-deep-research.md` - All changes

## ⚡ Quick Test

```python
# Test without env vars (should import OK)
from deep_research import pipeline
print("✅ Import successful")

# Test with missing vars (should raise ValueError)
try:
    pipeline._get_model()
except ValueError as e:
    print(f"✅ Validation working: {str(e)[:50]}...")
```

## 🔐 Security

- ✅ Don't commit `.env` to git
- ✅ Use Azure Key Vault in production
- ✅ Rotate keys regularly
- ✅ Set minimal permissions

## 🆘 Need Help?

1. Check logs: `tail -f logs/app.log`
2. Review setup guide: `docs/deep-research-setup.md`
3. Check troubleshooting: `docs/deep-research-fix.md`
4. Verify environment: Run verification script above
