# Feedback Data Storage

This directory stores user feedback ratings for AI responses in multiple formats:

- `feedback.csv` - CSV format for easy spreadsheet viewing
- `feedback.json` - JSON format for programmatic access
- `feedback.xlsx` - Excel format with proper formatting

## Fields Stored

Each feedback entry contains:

- **timestamp**: ISO 8601 timestamp when feedback was submitted (auto-generated)
- **session_id**: Unique chat session identifier (defaults to "unknown-session" if unavailable)
- **user_id**: User identifier (defaults to "anonymous" if unavailable)
- **model_used**: LLM model that generated the response (defaults to "unknown-model" if unavailable)
- **rating**: User rating (1-5 stars) **[REQUIRED]**
- **comment**: Optional user comment (max 500 characters)
- **user_message**: Original user message (truncated to 5000 chars)
- **ai_response**: AI response text (truncated to 10000 chars)
- **response_length**: Character count of AI response
- **rating_category**: Category based on rating (Poor/Average/Good) **[REQUIRED]**
- **message_id**: Unique message identifier (defaults to "unknown-message" if unavailable)

### Field Requirements

**Required Fields:**
- `rating` - Must be provided (1-5)
- `rating_category` - Must be provided (Poor/Average/Good)

**Optional Fields with Defaults:**
- `session_id` → "unknown-session"
- `user_id` → "anonymous"
- `model_used` → "unknown-model"
- `message_id` → "unknown-message"
- All other fields → empty or calculated

**Auto-generated:**
- `timestamp` - Added automatically when feedback is saved
- `response_length` - Calculated from ai_response

## Azure Blob Storage Sync

All feedback files are automatically synced to Azure Blob Storage:
- **Container**: `feedback`
- **Storage Account**: Configured via `APP_AZURE_STORAGE_ACCOUNT` environment variable

## Local Files

These files are excluded from Git via `.gitignore` to prevent exposing user feedback data.
They exist only locally and in Azure Blob Storage for centralized access.

## Accessing Feedback

To view feedback statistics, you can:
1. Open the Excel file directly
2. Import CSV into analytics tools
3. Parse JSON programmatically
4. Access via Azure Portal → Storage Account → `feedback` container
