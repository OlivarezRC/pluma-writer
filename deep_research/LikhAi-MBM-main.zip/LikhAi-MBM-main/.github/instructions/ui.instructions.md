---
applyTo: '**/*.css'
---

# Style notes

- Use dark mode
- Controls should have a modern look and feel
- Rounded corners for any boxes