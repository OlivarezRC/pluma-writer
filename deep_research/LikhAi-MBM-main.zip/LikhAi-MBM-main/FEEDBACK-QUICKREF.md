# Feedback System - Quick Reference

## 🌟 Visual Flow

```
┌─────────────────────────────────────────────────────────────┐
│                     USER INTERACTION                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    User asks question
                              │
                              ▼
                    AI generates response
                              │
                              ▼
        ╔═════════════════════════════════════════╗
        ║   AI Response with 5-Star Rating UI     ║
        ║   ☆ ☆ ☆ ☆ ☆  Rate this response        ║
        ╚═════════════════════════════════════════╝
                              │
                              ▼
                    User clicks a star (e.g., 4★)
                              │
                              ▼
        ╔═════════════════════════════════════════╗
        ║      Thank you for your rating!         ║
        ║         ★ ★ ★ ★ ☆ (4/5)                ║
        ║                                         ║
        ║  Would you like to add any comments?    ║
        ║  ┌─────────────────────────────────┐  ║
        ║  │ Your feedback (optional)...     │  ║
        ║  │                                 │  ║
        ║  └─────────────────────────────────┘  ║
        ║           0/500 characters              ║
        ║                                         ║
        ║      [Skip]  [Submit Feedback]          ║
        ╚═════════════════════════════════════════╝
                              │
                              ▼
                    User submits feedback
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   BACKEND PROCESSING                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
              @cl.action_callback("save_feedback")
                              │
                              ▼
                  FeedbackStorage.save_feedback()
                              │
          ┌───────────────────┼───────────────────┐
          │                   │                   │
          ▼                   ▼                   ▼
    Save to CSV         Save to JSON        Save to XLSX
    feedback.csv        feedback.json       feedback.xlsx
          │                   │                   │
          └───────────────────┼───────────────────┘
                              │
                              ▼
                  Upload to Azure Blob Storage
                         (feedback container)
                              │
                              ▼
        ╔═════════════════════════════════════════╗
        ║  ✓ Thank you for your feedback!         ║
        ╚═════════════════════════════════════════╝
```

## 📊 Data Schema

```
timestamp: "2025-11-20T07:37:00.186Z"
session_id: "sess_abc123"
user_id: "employee@bsp.gov.ph"
model_used: "foundry/gpt-4o"
rating: 5
comment: "Excellent response, very helpful!"
user_message: "What is BSP's monetary policy?"
ai_response: "The Bangko Sentral ng Pilipinas..."
response_length: 250
rating_category: "Good"
message_id: "msg_xyz789"
```

## 📁 File Structure

```
LikhAi-MBM/
├── app.py                              # Main app with feedback integration
├── demo_feedback.py                    # Demo script
├── public/
│   └── elements/
│       └── FeedbackRating.jsx         # React component (5-star UI)
├── utils/
│   └── feedback.py                    # Storage handler (CSV/JSON/XLSX/Blob)
├── data/
│   └── feedback/
│       ├── README.md
│       ├── feedback.csv              # ← Gitignored
│       ├── feedback.json             # ← Gitignored
│       └── feedback.xlsx             # ← Gitignored
├── tests/
│   └── test_feedback.py              # 8 unit tests (all passing)
└── docs/
    ├── feedback-system-guide.md      # Complete guide
    └── feedback-implementation-summary.md
```

## 🎯 Key Features

| Feature | Description | Status |
|---------|-------------|--------|
| 5-Star Rating | Visual star interface | ✅ |
| Comments | Optional 500-char feedback | ✅ |
| Multi-format Storage | CSV, JSON, XLSX | ✅ |
| Azure Blob Sync | Automatic cloud backup | ✅ |
| Analytics | Stats & distributions | ✅ |
| Dark Mode UI | Matches app theme | ✅ |
| Modal Dialog | Clean popup interface | ✅ |
| Auto-categorization | Poor/Average/Good | ✅ |

## 🚀 Quick Start

### Run Demo
```bash
python demo_feedback.py
```

### Run Tests
```bash
python -m pytest tests/test_feedback.py -v
```

### Start App
```bash
chainlit run app.py
```

## 💾 Storage Locations

### Local Files
```
data/feedback/feedback.csv
data/feedback/feedback.json
data/feedback/feedback.xlsx
```

### Azure Blob Storage
```
Container: feedback
Files: feedback.csv, feedback.json, feedback.xlsx
```

## 📈 Analytics Example

```python
from utils.feedback import get_feedback_storage

storage = get_feedback_storage()
stats = storage.get_feedback_stats()

print(f"Total: {stats['total_feedback']}")
print(f"Average: {stats['average_rating']:.2f}⭐")
print(f"Distribution: {stats['rating_distribution']}")
```

Output:
```
Total: 5
Average: 3.80⭐
Distribution: {5: 2, 4: 1, 3: 1, 2: 1}
```

## 🔧 Configuration

### Environment Variables
```bash
APP_AZURE_STORAGE_ACCOUNT=mbmchat
APP_AZURE_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=https;...
```

## ✅ Testing Results

```
8 tests, 8 passed, 0 failed
Coverage: 100% on feedback module
Demo: ✓ Working
Azure Sync: ✓ Functional
```

## 📞 Support

- Documentation: `docs/feedback-system-guide.md`
- Demo: `python demo_feedback.py`
- Tests: `pytest tests/test_feedback.py -v`
- Logs: `logs/app.log`

---

**Status**: ✅ Production Ready  
**Version**: 1.0.0  
**Last Updated**: November 20, 2025
