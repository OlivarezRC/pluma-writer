// public/elements/FeedbackRating.jsx
// Binary rating feedback component for AI responses (Accurate/Inaccurate)
// Captures user ratings and comments, sends to backend for storage
// Last updated: 2024-12-02 02:30:00

import { useState } from 'react';

export default function FeedbackRating({ messageId, sessionId, userId, model, userMessage, aiResponse }) {
  const [rating, setRating] = useState(null); // null, 'accurate', or 'inaccurate'
  const [showModal, setShowModal] = useState(false);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  // Debug: Log props when component mounts
  console.log('🔍 FeedbackRating props:', {
    messageId,
    sessionId,
    userId,
    model,
    userMessageLength: userMessage ? userMessage.length : 0,
    aiResponseLength: aiResponse ? aiResponse.length : 0
  });

  const handleRatingClick = (value) => {
    setRating(value);
    setShowModal(true);
  };

  const handleSubmit = async () => {
    try {
      // Require comment for inaccurate ratings
      if (rating === 'inaccurate' && !comment.trim()) {
        alert('Please provide a comment explaining why the response was inaccurate.');
        return;
      }

      // Determine rating category and numeric value for compatibility
      let ratingCategory = '';
      let numericRating = 0;
      if (rating === 'accurate') {
        ratingCategory = 'Accurate';
        numericRating = 5;
      } else if (rating === 'inaccurate') {
        ratingCategory = 'Inaccurate';
        numericRating = 2;
      }

      const feedbackData = {
        message_id: messageId,
        session_id: sessionId,
        user_id: userId,
        model_used: model,
        rating: numericRating,
        comment: comment,
        user_message: userMessage,
        ai_response: aiResponse,
        response_length: aiResponse ? aiResponse.length : 0,
        rating_category: ratingCategory
      };

      // Send feedback to backend
      const result = await callAction({
        name: "save_feedback",
        payload: feedbackData
      });

      if (result.success) {
        console.log('Feedback submitted successfully');
        setSubmitted(true);
        setTimeout(() => {
          setShowModal(false);
        }, 1500);
      } else {
        console.error('Failed to submit feedback');
        alert('Failed to submit feedback. Please try again.');
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Error submitting feedback. Please try again.');
    }
  };

  const handleSkip = () => {
    setShowModal(false);
  };

  return (
    <div style={{
      marginTop: '10px',
      padding: '10px',
      borderTop: '1px solid #333',
      display: 'flex',
      alignItems: 'center',
      gap: '10px'
    }}>
      <span style={{ 
        fontSize: '14px', 
        color: '#aaa',
        marginRight: '8px'
      }}>
        Is the reponse accurate?:
      </span>
      
      <button
        onClick={() => !submitted && handleRatingClick('accurate')}
        disabled={submitted}
        style={{
          padding: '6px 16px',
          backgroundColor: rating === 'accurate' ? '#4CAF50' : '#2d2d2d',
          color: rating === 'accurate' ? '#fff' : '#aaa',
          border: `1px solid ${rating === 'accurate' ? '#4CAF50' : '#555'}`,
          borderRadius: '6px',
          cursor: submitted ? 'default' : 'pointer',
          fontSize: '13px',
          fontWeight: '500',
          transition: 'all 0.2s',
          opacity: submitted ? 0.6 : 1
        }}
        onMouseEnter={(e) => {
          if (!submitted && rating !== 'accurate') {
            e.target.style.backgroundColor = '#333';
            e.target.style.borderColor = '#666';
          }
        }}
        onMouseLeave={(e) => {
          if (!submitted && rating !== 'accurate') {
            e.target.style.backgroundColor = '#2d2d2d';
            e.target.style.borderColor = '#555';
          }
        }}
      >
        ✓ Accurate
      </button>

      <button
        onClick={() => !submitted && handleRatingClick('inaccurate')}
        disabled={submitted}
        style={{
          padding: '6px 16px',
          backgroundColor: rating === 'inaccurate' ? '#f44336' : '#2d2d2d',
          color: rating === 'inaccurate' ? '#fff' : '#aaa',
          border: `1px solid ${rating === 'inaccurate' ? '#f44336' : '#555'}`,
          borderRadius: '6px',
          cursor: submitted ? 'default' : 'pointer',
          fontSize: '13px',
          fontWeight: '500',
          transition: 'all 0.2s',
          opacity: submitted ? 0.6 : 1
        }}
        onMouseEnter={(e) => {
          if (!submitted && rating !== 'inaccurate') {
            e.target.style.backgroundColor = '#333';
            e.target.style.borderColor = '#666';
          }
        }}
        onMouseLeave={(e) => {
          if (!submitted && rating !== 'inaccurate') {
            e.target.style.backgroundColor = '#2d2d2d';
            e.target.style.borderColor = '#555';
          }
        }}
      >
        ⚠ Inaccurate
      </button>

      {submitted && (
        <span style={{
          fontSize: '14px',
          color: '#4CAF50',
          marginLeft: '10px'
        }}>
          ✓ Thank you for your feedback!
        </span>
      )}

      {showModal && !submitted && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.7)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 10000
        }}>
          <div style={{
            backgroundColor: '#1e1e1e',
            borderRadius: '12px',
            padding: '30px',
            maxWidth: '450px',
            width: '90%',
            boxShadow: '0 10px 40px rgba(0, 0, 0, 0.5)',
            color: '#fff'
          }}>
            <h2 style={{
              margin: '0 0 15px 0',
              fontSize: '20px',
              fontWeight: '600',
              textAlign: 'center'
            }}>
              Thank you for your rating!
            </h2>

            <div style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '20px',
              padding: '15px',
              backgroundColor: rating === 'accurate' ? 'rgba(76, 175, 80, 0.1)' : 'rgba(244, 67, 54, 0.1)',
              borderRadius: '8px',
              border: `1px solid ${rating === 'accurate' ? '#4CAF50' : '#f44336'}`
            }}>
              <span style={{
                fontSize: '32px'
              }}>
                {rating === 'accurate' ? '✓' : '⚠'}
              </span>
              <span style={{
                fontSize: '18px',
                fontWeight: '500',
                color: rating === 'accurate' ? '#4CAF50' : '#f44336'
              }}>
                {rating === 'accurate' ? 'Accurate' : 'Inaccurate'}
              </span>
            </div>

            <p style={{
              margin: '0 0 15px 0',
              fontSize: '14px',
              color: '#ccc'
            }}>
              {rating === 'inaccurate' 
                ? 'Please explain why the response was inaccurate (required):'
                : 'Would you like to add any comments about this response?'}
            </p>

            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={rating === 'inaccurate' 
                ? 'Please explain why the response was inaccurate...' 
                : 'Your feedback (optional)...'}
              maxLength={500}
              style={{
                width: '100%',
                minHeight: '100px',
                padding: '12px',
                backgroundColor: '#2d2d2d',
                border: rating === 'inaccurate' ? '1px solid #f44336' : '1px solid #444',
                borderRadius: '8px',
                color: '#fff',
                fontSize: '14px',
                resize: 'vertical',
                fontFamily: 'inherit',
                boxSizing: 'border-box'
              }}
            />

            <div style={{
              textAlign: 'right',
              fontSize: '12px',
              color: '#888',
              marginTop: '5px'
            }}>
              {comment.length}/500 characters
            </div>

            <div style={{
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '10px',
              marginTop: '20px'
            }}>
              <button
                onClick={handleSkip}
                style={{
                  padding: '10px 24px',
                  backgroundColor: 'transparent',
                  color: '#aaa',
                  border: '1px solid #555',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#333';
                  e.target.style.borderColor = '#666';
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = 'transparent';
                  e.target.style.borderColor = '#555';
                }}
              >
                Skip
              </button>

              <button
                onClick={handleSubmit}
                style={{
                  padding: '10px 24px',
                  backgroundColor: '#0078D4',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  transition: 'background-color 0.2s'
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#106EBE'}
                onMouseLeave={(e) => e.target.style.backgroundColor = '#0078D4'}
              >
                Submit Feedback
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
