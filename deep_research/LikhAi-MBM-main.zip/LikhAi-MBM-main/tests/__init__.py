"""
BSP AI Assistant Test Package

This package contains test modules for the BSP AI Assistant application.
Currently includes placeholder for future test implementations.
"""

# This file makes the tests directory a Python package