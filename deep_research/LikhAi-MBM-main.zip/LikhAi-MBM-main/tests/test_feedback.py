"""
Unit tests for feedback storage system.

This module tests the FeedbackStorage class functionality including
local file storage (CSV, JSON, XLSX) and Azure Blob integration.
"""

import pytest
import os
import json
import pandas as pd
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from utils.feedback import FeedbackStorage, get_feedback_storage


@pytest.fixture
def feedback_storage(tmp_path):
    """Create a FeedbackStorage instance with temporary directory."""
    with patch('utils.feedback.Path') as mock_path:
        # Create actual temp directory structure
        feedback_dir = tmp_path / "data" / "feedback"
        feedback_dir.mkdir(parents=True, exist_ok=True)
        
        # Mock the Path to return our temp directory
        mock_path.return_value = feedback_dir
        
        with patch.dict(os.environ, {
            'APP_AZURE_STORAGE_ACCOUNT': 'test_account',
            'APP_AZURE_STORAGE_CONNECTION_STRING': ''
        }, clear=False):
            storage = FeedbackStorage()
            storage.feedback_dir = feedback_dir
            storage.csv_file = feedback_dir / "feedback.csv"
            storage.json_file = feedback_dir / "feedback.json"
            storage.xlsx_file = feedback_dir / "feedback.xlsx"
            storage.blob_service_client = None  # Disable Azure for tests
            storage._initialize_files()
            
            return storage


def test_feedback_storage_initialization(feedback_storage):
    """Test that feedback storage initializes correctly."""
    assert feedback_storage.csv_file.exists()
    assert feedback_storage.json_file.exists()
    assert feedback_storage.xlsx_file.exists()


def test_save_feedback_success(feedback_storage):
    """Test successful feedback save operation."""
    feedback_data = {
        'message_id': 'msg_123',
        'session_id': 'sess_456',
        'user_id': 'user_789',
        'model_used': 'gpt-4o',
        'rating': 5,
        'comment': 'Great response!',
        'user_message': 'Test question',
        'ai_response': 'Test answer',
        'response_length': 11,
        'rating_category': 'Good'
    }
    
    result = feedback_storage.save_feedback(feedback_data)
    assert result is True
    
    # Verify CSV
    with open(feedback_storage.csv_file, 'r') as f:
        lines = f.readlines()
        assert len(lines) == 2  # Header + 1 data row
    
    # Verify JSON
    with open(feedback_storage.json_file, 'r') as f:
        data = json.load(f)
        assert len(data) == 1
        assert data[0]['rating'] == 5
    
    # Verify XLSX
    df = pd.read_excel(feedback_storage.xlsx_file, engine='openpyxl')
    assert len(df) == 1
    assert df.iloc[0]['rating'] == 5


def test_save_feedback_missing_field(feedback_storage):
    """Test feedback save fails with missing required field."""
    feedback_data = {
        'session_id': 'sess_456',
        'user_id': 'user_789',
        # Missing required fields: model_used, rating, rating_category
    }
    
    result = feedback_storage.save_feedback(feedback_data)
    assert result is False


def test_save_feedback_missing_optional_fields(feedback_storage):
    """Test feedback save succeeds with missing optional fields."""
    feedback_data = {
        # session_id, user_id, message_id are optional (will use defaults)
        'model_used': 'gpt-4o',
        'rating': 4,
        'comment': 'Good',
        'user_message': 'Test',
        'ai_response': 'Response',
        'response_length': 8,
        'rating_category': 'Good'
    }
    
    result = feedback_storage.save_feedback(feedback_data)
    assert result is True
    
    # Verify defaults were applied
    with open(feedback_storage.json_file, 'r') as f:
        data = json.load(f)
        last_entry = data[-1]
        assert last_entry['session_id'] == 'unknown-session'
        assert last_entry['user_id'] == 'anonymous'
        assert last_entry['message_id'] == 'unknown-message'


def test_save_feedback_truncates_long_text(feedback_storage):
    """Test that long text fields are truncated."""
    feedback_data = {
        'message_id': 'msg_123',
        'session_id': 'sess_456',
        'user_id': 'user_789',
        'model_used': 'gpt-4o',
        'rating': 4,
        'comment': 'A' * 1000,  # Exceeds 500 char limit
        'user_message': 'B' * 6000,  # Exceeds 5000 char limit
        'ai_response': 'C' * 15000,  # Exceeds 10000 char limit
        'response_length': 15000,
        'rating_category': 'Good'
    }
    
    result = feedback_storage.save_feedback(feedback_data)
    assert result is True
    
    # Verify truncation in JSON
    with open(feedback_storage.json_file, 'r') as f:
        data = json.load(f)
        assert len(data[0]['comment']) == 500
        assert len(data[0]['user_message']) == 5000
        assert len(data[0]['ai_response']) == 10000


def test_get_feedback_stats(feedback_storage):
    """Test feedback statistics calculation."""
    # Add multiple feedback entries
    for rating in [5, 4, 3, 5, 2]:
        feedback_data = {
            'message_id': f'msg_{rating}',
            'session_id': 'sess_456',
            'user_id': 'user_789',
            'model_used': 'gpt-4o',
            'rating': rating,
            'comment': 'Test',
            'user_message': 'Test question',
            'ai_response': 'Test answer',
            'response_length': 11,
            'rating_category': 'Good' if rating >= 4 else 'Average' if rating == 3 else 'Poor'
        }
        feedback_storage.save_feedback(feedback_data)
    
    stats = feedback_storage.get_feedback_stats()
    assert stats['total_feedback'] == 5
    assert stats['average_rating'] == 3.8
    assert 5 in stats['rating_distribution']
    assert 'gpt-4o' in stats['models_rated']


def test_get_feedback_storage_singleton():
    """Test that get_feedback_storage returns singleton instance."""
    storage1 = get_feedback_storage()
    storage2 = get_feedback_storage()
    assert storage1 is storage2


@patch('utils.feedback.BlobServiceClient')
def test_azure_blob_upload(mock_blob_client, feedback_storage):
    """Test Azure Blob Storage upload functionality."""
    # Setup mock
    mock_container = MagicMock()
    mock_blob = MagicMock()
    mock_container.get_blob_client.return_value = mock_blob
    mock_blob_service = MagicMock()
    mock_blob_service.get_container_client.return_value = mock_container
    
    feedback_storage.blob_service_client = mock_blob_service
    
    # Save feedback
    feedback_data = {
        'message_id': 'msg_123',
        'session_id': 'sess_456',
        'user_id': 'user_789',
        'model_used': 'gpt-4o',
        'rating': 5,
        'comment': 'Great!',
        'user_message': 'Test',
        'ai_response': 'Test',
        'response_length': 4,
        'rating_category': 'Good'
    }
    
    result = feedback_storage.save_feedback(feedback_data)
    assert result is True
    
    # Verify blob upload was called
    assert mock_blob.upload_blob.called


def test_rating_category_calculation():
    """Test that rating categories are correctly assigned."""
    test_cases = [
        (1, 'Poor'),
        (2, 'Poor'),
        (3, 'Average'),
        (4, 'Good'),
        (5, 'Good')
    ]
    
    for rating, expected_category in test_cases:
        if rating in [1, 2]:
            category = 'Poor'
        elif rating == 3:
            category = 'Average'
        else:
            category = 'Good'
        
        assert category == expected_category
